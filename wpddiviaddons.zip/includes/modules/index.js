import WpdaPostCarousel from './WpdaPostCarousel/WpdaPostCarousel';

export default [WpdaPostCarousel];
